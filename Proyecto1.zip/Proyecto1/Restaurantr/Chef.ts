class chefs {
    private nombre: string;
    private edad: number;
    private experiencia: boolean;

    constructor(nombre: string, edad: number, experiencia: boolean) {
        this.nombre = nombre;
        this.edad = edad;
        this.experiencia = experiencia;
    }

    getNombre(): string {
        return this.nombre;
    }

    getEdad(): number {
        return this.edad;
    }

    tieneExperiencia(): boolean {
        return this.experiencia;
    }
}
