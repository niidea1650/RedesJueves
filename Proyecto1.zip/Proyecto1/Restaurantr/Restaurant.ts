class Restaurante {
    private nombre: string;
    private chefs: Chef[];
    private menu: Plato[];

    constructor(nombre: string) {
        this.nombre = nombre;
        this.chefs = [];
        this.menu = [];
    }

    contratarChef(chefs: chefs): void {
        if (chefs.getEdad() < 18 || !chefs.tieneExperiencia()) {
            throw new Error("El chef no cumple con los requisitos necesarios para ser contratado.");
        }
        this.chefs.push(chefs);
        console.log(`El chef ${chefs.getNombre()} se unió al equipo de ${this.nombre}.`);
    }

    agregarPlato(plato: Plato, chefs: Chef): void {
        if (this.menu.find(item => item.getNombre() === plato.getNombre())) {
            throw new Error("El plato ya está en el menú.");
        }
        if (!this.chefs.includes(chefs)) {
            throw new Error("El chef no está contratado en el restaurante.");
        }
        this.menu.push(plato);
        console.log(`El plato ${plato.getNombre()} se agregó al menú de ${this.nombre}.`);
    }
}
