class Plato {
    private nombre: string;
    private descripcion: string;
    private precio: number;
    private tipo: string;

    constructor(nombre: string, descripcion: string, precio: number, tipo: string) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.tipo = tipo;
    }

    getNombre(): string {
        return this.nombre;
    }

    getDescripcion(): string {
        return this.descripcion;
    }

    getPrecio(): number {
        return this.precio;
    }

    getTipo(): string {
        return this.tipo;
    }
}