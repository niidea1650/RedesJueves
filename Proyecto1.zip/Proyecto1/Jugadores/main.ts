//console.log("hola mundo");

//let ta: number;
//ta = 10;
//console.log(ta);

class Persona {
    private nombre : string;
    private apellido : string;
    constructor(nombre:string, apellido:string) {
       this.nombre = nombre;
       this.apellido = apellido;
    }
    getnombre() : string {
        return this.nombre;
    }
    setnombre(values : string){
        this.nombre = values;
    } 
    public getApellido(): string {
        return this.apellido;
    }

    public setApellido(apellido: string): void {
        this.apellido = apellido;
    }
    
}

class Chef extends Persona{
    f_nacimiento : Date;
    experiencia : boolean;
    constructor(nombre:string, apellido:string, f_nacimiento:Date, experiencia:boolean){
        super(nombre,apellido);
        this.experiencia = experiencia;
        this.f_nacimiento = f_nacimiento;
    }
    getf_nacimiento() : Date {
        return this.f_nacimiento;
    }
    setf_nacimiento(values : Date){
        this.f_nacimiento = values;
    } 
    getexperiencia() : boolean {
        return this.experiencia;
    }
    setexperiencia(values : boolean){
        this.experiencia = values;
    } 
}
class plato{
    nombrep : string; 
    tipo : tipo;
    constructor(nombrep:string, tipo: tipo){
        this.nombrep = nombrep;
        this.tipo = tipo;
    } 

}


enum tipo {
    ENTRADA,
    PLATO_PRINCIPAL,
    POSTRE
}