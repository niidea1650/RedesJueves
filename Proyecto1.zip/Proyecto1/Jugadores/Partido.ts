class Partido {
    equipoLocal: string;
    equipoVisitante: string;
    resultado: string;

    constructor(equipoLocal: string, equipoVisitante: string, resultado: string) {
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.resultado = resultado;
    }
}

interface Contrato {
    contratar(jugador: Jugador, nombreClub: string): void;
    renovar(jugador: Jugador, nombreClub: string): void;
}

// Implementación de la clase EquipoFutbolArgentino
class EquipoFutbolArgentino implements Contrato {
    jugadores: Jugador[];
    partidosJugados: Partido[];

    constructor() {
        this.jugadores = [];
        this.partidosJugados = [];
    }

    agregarJugador(jugador: Jugador) {
        this.jugadores.push(jugador);
    }

    agregarPartido(partido: Partido) {
        this.partidosJugados.push(partido);
        // Actualizar información de los jugadores en función del partido
        // Aquí implementarías la lógica para actualizar los porcentajes, goles recibidos, goles convertidos, etc.
    }

    contratar(jugador: Jugador, nombreClub: string): void {
        if (jugador.historialEquipos.includes(nombreClub)) {
            throw new Error("El jugador ya ha jugado en el club que ofrece el contrato.");
        }

        if (jugador instanceof Arquero) {
            const arquero = jugador as Arquero;
            if (arquero.porcentajeAtajadas <= 60 || arquero.golesRecibidos >= 10) {
                throw new Error("El arquero no cumple con los requisitos para ser contratado.");
            }
        } else if (jugador instanceof JugadorCampo) {
            const jugadorCampo = jugador as JugadorCampo;
            if (jugadorCampo.porcentajeGolesConvertidos <= 30 || jugadorCampo.asistenciasRealizadas <= 10) {
                throw new Error("El jugador de campo no cumple con los requisitos para ser contratado.");
            }
        }
    }

    renovar(jugador: Jugador, nombreClub: string): void {
        if (!jugador.historialEquipos.includes(nombreClub)) {
            throw new Error("El jugador no ha jugado en el club que ofrece el contrato.");
        }

        if (jugador instanceof Arquero) {
            const arquero = jugador as Arquero;
            if (arquero.calcularEdad > 35) {
                throw new Error("El arquero es mayor de 35 años y no puede renovar contrato.");
            }
        }
        console.log(`El jugador ${jugador.nombre} se renovó en el club ${nombreClub}.`);
    }
}