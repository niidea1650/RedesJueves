class Jugador {
    nombre: string;
    fechaNacimiento: string;
    posicion: string;
    provincia: string;
    historialEquipos: string[];
    numeroCamiseta: number;
    edad : number;
 
    constructor(nombre: string, fechaNacimiento: string, posicion: string, provincia: string, historialEquipos: string[], numeroCamiseta: number) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.posicion = posicion;
        this.provincia = provincia;
        this.historialEquipos = historialEquipos;
        this.numeroCamiseta = numeroCamiseta;
        this.edad = this.calcularEdad;
    }

    calcularEdad(): number {
        const fechaActual = new Date();
        const fechaNacimiento = new Date(this.fechaNacimiento);
        let edad = fechaActual.getFullYear() - fechaNacimiento.getFullYear();
        return edad;
    }
    
}