class Arquero extends Jugador {
    porcentajeAtajadas: number;
    golesRecibidos: number;
    edad: number;
 
    constructor(nombre: string, fechaNacimiento: string, posicion: string, provincia: string, historialEquipos: string[], numeroCamiseta: number, porcentajeAtajadas: number, golesRecibidos: number, edad: number) {
        super(nombre, fechaNacimiento, posicion, provincia, historialEquipos, numeroCamiseta);
        this.porcentajeAtajadas = porcentajeAtajadas;
        this.golesRecibidos = golesRecibidos;
        this.edad = edad;
    }
}
 