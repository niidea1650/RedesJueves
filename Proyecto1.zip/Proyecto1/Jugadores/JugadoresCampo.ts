class JugadorCampo extends Jugador {
    porcentajeGolesConvertidos: number;
    asistenciasRealizadas: number;
 
    constructor(nombre: string, fechaNacimiento: string, posicion: string, provincia: string, historialEquipos: string[], numeroCamiseta: number, porcentajeGolesConvertidos: number, asistenciasRealizadas: number) {
        super(nombre, fechaNacimiento, posicion, provincia, historialEquipos, numeroCamiseta);
        this.porcentajeGolesConvertidos = porcentajeGolesConvertidos;
        this.asistenciasRealizadas = asistenciasRealizadas;
    }
}